/* halaman statistik: hitung jumlah titik */
document.addEventListener("DOMContentLoaded", () => {
  const d = semua();
  document.getElementById("total").textContent = d.length;
  document.getElementById("usul").textContent = d.filter((x) => x.u).length;
  function bar(id, keys, fn, lab) {
    const c = keys.map((k) => d.filter((x) => fn(x) == k).length),
      mx = Math.max(1, ...c);
    document.getElementById(id).innerHTML = keys
      .map(
        (k, i) =>
          '<div class="batang"><span>' +
          lab(k) +
          '</span><i style="width:' +
          (c[i] / mx) * 100 +
          '%"></i><b>' +
          c[i] +
          "</b></div>",
      )
      .join("");
  }
  bar(
    "perjenis",
    Object.keys(JENIS),
    (x) => x.j,
    (k) => JENIS[k].label.replace(/ \(.*\)/, ""),
  );
  bar(
    "perkec",
    KECAMATAN,
    (x) => x.k,
    (k) => k,
  );
});
