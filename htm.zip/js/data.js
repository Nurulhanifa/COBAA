/* data jenis pin dan lokasi contoh, dipakai semua halaman */
const JENIS = {
  kecil: { label: "Tong sampah kecil", kode: "K", warna: "#2e9e6b" },
  besar: { label: "Tong sampah besar", kode: "B", warna: "#2a6fb0" },
  tps: { label: "Tempat pembuangan sementara (TPS)", kode: "S", warna: "#e08a12" },
  tpa: { label: "Tempat pembuangan akhir (TPA)", kode: "A", warna: "#b83a2e" },
};
const KECAMATAN = [
  "Andir",
  "Astana Anyar",
  "Bandung Wetan",
  "Batununggal",
  "Cibeunying Kidul",
  "Cicendo",
  "Coblong",
  "Gedebage",
  "Lengkong",
  "Regol",
  "Sukajadi",
  "Sumur Bandung",
  "Di luar Kota Bandung",
];
/* Data contoh untuk demo. Koordinat perkiraan, bukan hasil survei lapangan. */
const SEED = [
  {
    n: "Tong di sisi Alun-alun",
    j: "kecil",
    k: "Sumur Bandung",
    a: "Sekitar Alun-alun Bandung",
    lat: -6.9218,
    lng: 107.6071,
  },
  {
    n: "Tong dekat Stasiun Bandung",
    j: "kecil",
    k: "Andir",
    a: "Sisi selatan Stasiun Bandung",
    lat: -6.9147,
    lng: 107.602,
  },
  {
    n: "Tong Gedung Sate",
    j: "kecil",
    k: "Bandung Wetan",
    a: "Taman depan Gedung Sate",
    lat: -6.9025,
    lng: 107.6186,
  },
  {
    n: "Tong Taman Dago",
    j: "kecil",
    k: "Coblong",
    a: "Jalan Ir. H. Juanda (Dago)",
    lat: -6.8847,
    lng: 107.6131,
  },
  {
    n: "Tong sekitar kampus ITB",
    j: "kecil",
    k: "Coblong",
    a: "Jalan Ganesha",
    lat: -6.8915,
    lng: 107.6107,
  },
  {
    n: "Tong Cihampelas",
    j: "kecil",
    k: "Coblong",
    a: "Jalan Cihampelas",
    lat: -6.896,
    lng: 107.605,
  },
  {
    n: "Tong Taman Lansia",
    j: "kecil",
    k: "Bandung Wetan",
    a: "Jalan Cisangkuy",
    lat: -6.904,
    lng: 107.619,
  },
  {
    n: "Bak besar Pasar Baru",
    j: "besar",
    k: "Andir",
    a: "Area parkir Pasar Baru",
    lat: -6.919,
    lng: 107.604,
  },
  {
    n: "Bak besar Pasar Kosambi",
    j: "besar",
    k: "Regol",
    a: "Sekitar Pasar Kosambi",
    lat: -6.918,
    lng: 107.615,
  },
  {
    n: "Bak besar Jalan Buah Batu",
    j: "besar",
    k: "Lengkong",
    a: "Jalan Buah Batu",
    lat: -6.94,
    lng: 107.634,
  },
  {
    n: "Bak besar Sukajadi",
    j: "besar",
    k: "Sukajadi",
    a: "Jalan Sukajadi",
    lat: -6.885,
    lng: 107.596,
  },
  {
    n: "TPS contoh Pasar Induk",
    j: "tps",
    k: "Regol",
    a: "Sekitar Pasar Induk Caringin",
    lat: -6.9422,
    lng: 107.5878,
  },
  {
    n: "TPS contoh Gedebage",
    j: "tps",
    k: "Gedebage",
    a: "Kawasan Gedebage",
    lat: -6.948,
    lng: 107.699,
  },
  {
    n: "TPS contoh Cicendo",
    j: "tps",
    k: "Cicendo",
    a: "Sekitar Jalan Pasirkaliki",
    lat: -6.906,
    lng: 107.595,
  },
  {
    n: "TPS contoh Batununggal",
    j: "tps",
    k: "Batununggal",
    a: "Sekitar Jalan Kiaracondong",
    lat: -6.931,
    lng: 107.645,
  },
  {
    n: "TPA Sarimukti (perkiraan)",
    j: "tpa",
    k: "Di luar Kota Bandung",
    a: "Cipatat, Kabupaten Bandung Barat",
    lat: -6.83,
    lng: 107.39,
  },
];
const KUNCI = "tsb_usulan";
function usulan() {
  try {
    return JSON.parse(localStorage.getItem(KUNCI)) || [];
  } catch (e) {
    return [];
  }
}
function simpanUsulan(a) {
  try {
    localStorage.setItem(KUNCI, JSON.stringify(a));
    return true;
  } catch (e) {
    return false;
  }
}
function semua() {
  return SEED.map((x) => ({ ...x, u: false })).concat(usulan().map((x) => ({ ...x, u: true })));
}
function ikon(j) {
  return L.divIcon({
    className: "",
    html: '<span class="pin ' + j + '"><span>' + JENIS[j].kode + "</span></span>",
    iconSize: [28, 28],
    iconAnchor: [14, 28],
    popupAnchor: [0, -26],
  });
}
function popup(x) {
  return (
    "<strong>" +
    esc(x.n) +
    "</strong><br>" +
    JENIS[x.j].label +
    "<br>" +
    esc(x.k) +
    "<br>" +
    esc(x.a) +
    (x.c ? "<br><em>" + esc(x.c) + "</em>" : "") +
    (x.u ? "<br><small>Usulan pengguna (demo lokal)</small>" : "")
  );
}
function esc(s) {
  return String(s || "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}
function peta(id, zoom) {
  const m = L.map(id).setView([-6.9147, 107.6098], zoom || 12);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; kontributor OpenStreetMap",
  }).addTo(m);
  return m;
}
document.addEventListener("DOMContentLoaded", () => {
  const b = document.getElementById("menu"),
    n = document.querySelector("nav");
  if (b)
    b.onclick = () => {
      const o = n.classList.toggle("buka");
      b.setAttribute("aria-expanded", o);
    };
});
