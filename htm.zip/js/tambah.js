/* halaman tambah lokasi: pilih titik di peta lalu simpan ke localStorage */
document.addEventListener("DOMContentLoaded", () => {
  const m = peta("pilih", 12);
  let mk = null;
  const lat = document.getElementById("lat"),
    lng = document.getElementById("lng");
  semua().forEach((x) =>
    L.marker([x.lat, x.lng], { icon: ikon(x.j), opacity: 0.55 })
      .bindPopup(popup(x))
      .addTo(m),
  );
  m.on("click", (e) => {
    lat.value = e.latlng.lat.toFixed(6);
    lng.value = e.latlng.lng.toFixed(6);
    if (mk) mk.setLatLng(e.latlng);
    else mk = L.marker(e.latlng).addTo(m);
  });
  const sel = document.getElementById("kec");
  KECAMATAN.forEach((k) => sel.add(new Option(k, k)));
  const js = document.getElementById("jenis");
  Object.keys(JENIS).forEach((k) => js.add(new Option(JENIS[k].label, k)));
  const info = document.getElementById("info");
  document.getElementById("form").onsubmit = (e) => {
    e.preventDefault();
    if (!lat.value) {
      info.style.display = "block";
      info.style.background = "#fbe0dc";
      info.style.color = "#6b1d14";
      info.textContent = "Pilih titik di peta terlebih dahulu dengan mengklik lokasinya.";
      return;
    }
    const a = usulan();
    a.push({
      n: document.getElementById("nama").value.trim(),
      j: js.value,
      k: sel.value,
      a: document.getElementById("alamat").value.trim(),
      c: document.getElementById("cat").value.trim(),
      lat: +lat.value,
      lng: +lng.value,
    });
    const ok = simpanUsulan(a);
    info.style.display = "block";
    info.style.background = ok ? "#dff3e8" : "#fbe0dc";
    info.style.color = ok ? "#12402e" : "#6b1d14";
    info.innerHTML = ok
      ? 'Lokasi tersimpan di browser ini. <a href="peta.html">Lihat di peta</a>'
      : "Penyimpanan browser tidak tersedia. Aktifkan penyimpanan lokal lalu coba lagi.";
    if (ok) {
      e.target.reset();
      lat.value = lng.value = "";
      if (mk) {
        m.removeLayer(mk);
        mk = null;
      }
    }
  };
  document.getElementById("hapus").onclick = () => {
    if (confirm("Hapus semua usulan yang tersimpan di browser ini?")) {
      simpanUsulan([]);
      location.reload();
    }
  };
});
