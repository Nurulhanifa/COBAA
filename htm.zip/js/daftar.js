/* halaman daftar lokasi: tabel dengan filter */
document.addEventListener("DOMContentLoaded", () => {
  const fj = document.getElementById("fj"),
    fk = document.getElementById("fk"),
    tb = document.querySelector("tbody");
  Object.keys(JENIS).forEach((k) => fj.add(new Option(JENIS[k].label, k)));
  KECAMATAN.forEach((k) => fk.add(new Option(k, k)));
  function t() {
    const d = semua().filter(
      (x) => (!fj.value || x.j == fj.value) && (!fk.value || x.k == fk.value),
    );
    tb.innerHTML = d.length
      ? d
          .map(
            (x, i) =>
              "<tr><td>" +
              (i + 1) +
              "</td><td>" +
              esc(x.n) +
              (x.u ? " <small>(usulan)</small>" : "") +
              "</td><td>" +
              JENIS[x.j].label +
              "</td><td>" +
              esc(x.k) +
              "</td><td>" +
              esc(x.a) +
              "</td></tr>",
          )
          .join("")
      : '<tr><td colspan="5">Belum ada lokasi untuk filter ini. Coba ubah filter atau <a href="tambah-lokasi.html">tambahkan lokasi</a>.</td></tr>';
  }
  fj.onchange = fk.onchange = t;
  t();
});
