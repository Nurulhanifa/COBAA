/* peta utama: tampilkan pin dan filter */
document.addEventListener("DOMContentLoaded", () => {
  const full = !!document.getElementById("filter");
  const m = peta("peta", full ? 12 : 11),
    g = L.layerGroup().addTo(m);
  function gambar() {
    g.clearLayers();
    const on = [...document.querySelectorAll("#filter input")]
      .filter((i) => i.checked)
      .map((i) => i.value);
    let n = 0;
    semua().forEach((x) => {
      if (full && !on.includes(x.j)) return;
      n++;
      L.marker([x.lat, x.lng], { icon: ikon(x.j), title: x.n })
        .bindPopup(popup(x))
        .addTo(g);
    });
    const c = document.getElementById("jumlah");
    if (c) c.textContent = n + " lokasi ditampilkan";
  }
  if (full) {
    document.querySelectorAll("#filter input").forEach((i) => (i.onchange = gambar));
    document.getElementById("lokasiSaya").onclick = () => {
      const s = document.getElementById("status");
      if (!navigator.geolocation) {
        s.textContent = "Browser tidak mendukung lokasi.";
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (p) => {
          m.setView([p.coords.latitude, p.coords.longitude], 16);
          L.circleMarker([p.coords.latitude, p.coords.longitude], {
            radius: 8,
            color: "#fff",
            fillColor: "#1f5a45",
            fillOpacity: 1,
          })
            .addTo(m)
            .bindPopup("Posisi Anda");
          s.textContent = "";
        },
        () =>
          (s.textContent = "Izin lokasi ditolak. Aktifkan izin lokasi di browser lalu coba lagi."),
      );
    };
  }
  gambar();
});
